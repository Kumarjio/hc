<?php

$connInfo = array('connectionName:vh118:i:7ebc4319f51f3ea4648ceddfeb5aece7:This is the connection for vh118.infusionsoft.com');

?>
<?php
	class Candidate_Education extends AppModel 
	{
		var $name = 'candidate_education';
		var $useTable = 'candidate_education';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
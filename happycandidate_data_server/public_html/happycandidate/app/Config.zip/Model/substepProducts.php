    <?php
		class substepProducts extends AppModel 
		{
			var $name = 'substepProducts';
			var $useTable = 'substep_products';
		}
    ?>

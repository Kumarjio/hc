<?php
	class Candidate_extra extends AppModel 
	{
		var $name = 'Candidate_extra';
		var $useTable = 'candidate_extra_curricular';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
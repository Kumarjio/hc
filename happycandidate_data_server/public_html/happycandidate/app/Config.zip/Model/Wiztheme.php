<?php
	class Wiztheme extends AppModel 
	{
		var $name = 'Wiztheme';
		var $useTable = 'wizard_theme';

	}
?>
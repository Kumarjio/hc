<?php
	class Candidate_grants extends AppModel 
	{
		var $name = 'Candidate_grants';
		var $useTable = 'candidate_grants';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
<?php
	class PortalContactForm extends AppModel 
	{
		public $name = 'PortalContactForm';
		public $useTable = 'career_portal_contact_us_form';

	}
?>
<?php
	class Candidate_Comm_Involve extends AppModel 
	{
		var $name = 'candidate_comm_involve';
		var $useTable = 'candidate_comm_involve';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
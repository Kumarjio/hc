<?php
	class CandidateCvDetail extends AppModel 
	{
		public $name = 'CandidateCvDetail';
		public $useTable = 'jobberland_cv_detail';
		public $validate = array();
		
		
	}
?>
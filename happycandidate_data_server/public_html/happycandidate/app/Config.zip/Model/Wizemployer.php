<?php
	class Wizemployer extends AppModel 
	{
		var $name = 'Wizemployer';
		var $useTable = 'wizard_setup';

	}
?>
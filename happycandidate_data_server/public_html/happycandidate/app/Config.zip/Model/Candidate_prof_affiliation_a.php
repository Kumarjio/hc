<?php
	class Candidate_prof_affiliation_a extends AppModel 
	{
		var $name = 'Candidate_prof_affiliation_a';
		var $useTable = 'candidate_prof_affilations_academic';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
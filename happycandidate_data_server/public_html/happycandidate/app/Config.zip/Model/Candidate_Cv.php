<?php
	class Candidate_Cv extends AppModel 
	{
		var $name = 'candidate_cv';
		var $useTable = 'candidate_cv';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
<?php
	class Hclmslogin extends AppModel 
	{
		var $name = 'Hclmslogin';
		var $useTable = 'mdl_current_login_access_hc_lms';

	}
?>
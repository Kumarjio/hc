<?php
	class PortalThemeAllocated extends AppModel 
	{
		public $name = 'PortalThemeAllocated';
		public $useTable = 'career_portal_theme';
	}
?>
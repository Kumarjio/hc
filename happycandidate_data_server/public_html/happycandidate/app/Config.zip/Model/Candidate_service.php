<?php
	class Candidate_service extends AppModel 
	{
		var $name = 'Candidate_service';
		var $useTable = 'candidate_service';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
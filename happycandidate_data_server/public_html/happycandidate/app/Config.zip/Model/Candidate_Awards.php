<?php
	class Candidate_Awards extends AppModel 
	{
		var $name = 'candidate_awards';
		var $useTable = 'candidate_awards';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
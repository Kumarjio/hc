<?php
	class JobberlandCounties extends AppModel 	{
		public $name = 'JobberlandCounties';
		public $useTable = 'jobberland_countries';
		public $validate = array();
	
	}
?>
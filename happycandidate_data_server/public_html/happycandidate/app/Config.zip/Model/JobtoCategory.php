<?php
	class JobtoCategory extends AppModel 
	{
		var $name = 'JobtoCategory';
		var $useTable = 'jobberland_job2category';		
		
	}
?>
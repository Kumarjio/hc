<?php
	class Candidate_Education_f extends AppModel 
	{
		var $name = 'Candidate_Education_f';
		var $useTable = 'candidate_f_education';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
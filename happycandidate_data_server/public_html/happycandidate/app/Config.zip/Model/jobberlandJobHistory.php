    <?php
		class jobberlandJobHistory extends AppModel 
		{
			var $name = 'jobberlandJobHistory';
			var $useTable = 'jobberland_job_history';
		}
    ?>

<?php
	class FieldValidation extends AppModel 
	{
		public $name = 'FieldValidation';
		public $useTable = 'field_validation';
		
	}
?>
<?php
	class Candidate_prof_exp extends AppModel 
	{
		var $name = 'candidate_prof_exp';
		var $useTable = 'candidate_prof_exp';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
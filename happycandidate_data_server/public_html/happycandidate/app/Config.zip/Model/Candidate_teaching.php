<?php
	class Candidate_teaching extends AppModel 
	{
		var $name = 'Candidate_teaching';
		var $useTable = 'candidate_teaching';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
<?php
	class JobType extends AppModel 
	{
		var $name = 'JobType';
		var $useTable = 'types';		
		
	}
?>
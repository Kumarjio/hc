<?php
	class JobCategory extends AppModel 
	{
		var $name = 'JobCategory';
		var $useTable = 'jobberland_category';		
		
	}
?>
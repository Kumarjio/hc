<?php
	class CandidatesSettings extends AppModel 
	{
		var $name = 'CandidatesSettings';
		var $useTable = 'candidate_settings';
							 
	}
?>

<?php
	class Candidate_prof_affilations extends AppModel 
	{
		var $name = 'candidate_prof_affilations';
		var $useTable = 'candidate_prof_affilations';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
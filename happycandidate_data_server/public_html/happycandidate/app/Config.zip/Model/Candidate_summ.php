<?php
	class Candidate_summ extends AppModel 
	{
		var $name = 'Candidate_summ';
		var $useTable = 'candidate_skillsumm';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
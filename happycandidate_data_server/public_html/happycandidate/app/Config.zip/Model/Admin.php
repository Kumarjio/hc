    <?php
		class Admin extends AppModel 
		{
			var $name = 'Admin';
			var $useTable = 'admin_detail';
			var $validate = array(
							        'admin_fname' 			=> array(
																		'alphaNumeric' => array(
																								'rule' => 'notEmpty',
																								'message' => 'First name cannot be empty',
																			   )
																	),
									'admin_lname' 			=> array(
																		"lname" => array(
																								'rule' => 'notEmpty',
																								"message"=>"Last name cannot be empty"
																				 )
																	),
									'admin_contact_number' 	=> array(
																		'Numeric' => array(
																								'rule' => 'numeric',
																								'message' => 'Phone number should be in digits',
																						  )
																	),
									'admin_pin' 			=> array(
																		"postalcode" => array(
																								'rule' => 'notEmpty',
																								"message"=>"Postal code cannot be empty"
																				 )
																	),
									'admin_country' 			=> array(
																		"admincount" => array(
																								'rule' => 'notEmpty',
																								"message"=>"Country cannot be empty"
																				 )
																	),
									'admin_state' 			=> array(
																		"adminstate" => array(
																								'rule' => 'notEmpty',
																								"message"=>"State / Province / Region cannot be empty"
																				 )
																	)
								 );
								 
			public function beforeSave($options = array())
			{
			}
			
			public function fnCheckUserAccountExists($strEmail = "")
			{
				if($strEmail)
				{
					$arrReturnArray = $this->query("SELECT id FROM users WHERE email='".$strEmail."'");
					return count($arrReturnArray);
				}
				else
				{
					return false;
				}
			}
		}
    ?>

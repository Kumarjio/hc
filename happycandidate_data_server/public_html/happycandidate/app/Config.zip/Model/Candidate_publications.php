<?php
	class Candidate_publications extends AppModel 
	{
		var $name = 'Candidate_publications';
		var $useTable = 'candidate_publications';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
<?php
	class Candidate_lang extends AppModel 
	{
		var $name = 'Candidate_lang';
		var $useTable = 'candidate_lang';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
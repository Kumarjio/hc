<?php
	class CandidateCoverDetail extends AppModel 
	{
		public $name = 'CandidateCoverDetail';
		public $useTable = 'jobberland_covering_letter';
		public $validate = array();
		
		
	}
?>
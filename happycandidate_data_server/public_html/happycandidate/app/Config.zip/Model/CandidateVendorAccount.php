<?php
	class CandidateVendorAccount extends AppModel 
	{
		var $name = 'CandidateVendorAccount';
		var $useTable = 'candidate_vendor_account';
		
		
	}
?>
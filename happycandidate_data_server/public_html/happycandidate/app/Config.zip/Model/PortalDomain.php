<?php
	class PortalDomain extends AppModel 
	{
		public $name = 'PortalDomain';
		public $useTable = 'career_portal_domain';
	}
?>
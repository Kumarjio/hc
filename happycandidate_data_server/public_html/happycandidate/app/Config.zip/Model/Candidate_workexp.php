<?php
	class Candidate_workexp extends AppModel 
	{
		var $name = 'Candidate_workexp';
		var $useTable = 'candidate_work_exp';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
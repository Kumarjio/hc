<?php
	class Candidate_prof_exp_acc extends AppModel 
	{
		var $name = 'Candidate_prof_exp_acc';
		var $useTable = 'cand_prof_exp_acc';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
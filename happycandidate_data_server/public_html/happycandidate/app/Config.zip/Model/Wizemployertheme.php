<?php
	class Wizemployertheme extends AppModel 
	{
		var $name = 'Wizemployertheme';
		var $useTable = 'employer_wizard_theme';

	}
?>
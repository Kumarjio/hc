<?php
	class CandidateReferences extends AppModel 
	{
		var $name = 'CandidateReferences';
		var $useTable = 'candidate_references';
							 
	}
?>

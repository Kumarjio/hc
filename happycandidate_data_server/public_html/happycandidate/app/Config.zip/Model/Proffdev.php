<?php
	class Proffdev extends AppModel 
	{
		var $name = 'Proffdev';
		var $useTable = 'candidate_prof_dev';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
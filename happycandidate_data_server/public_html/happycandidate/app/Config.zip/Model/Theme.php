<?php
	class Theme extends AppModel 
	{
		public $name = 'Theme';
		public $useTable = 'theme';
		
	}
?>
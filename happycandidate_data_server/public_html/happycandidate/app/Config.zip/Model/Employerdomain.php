<?php
	class Employerdomain extends AppModel 
	{
		var $name = 'Employerdomain';
		var $useTable = 'employer_domain';
		 
							 
		public function beforeSave($options = array())
		{
		}
		
		
	}
?>
<?php
	class Resumesteps extends AppModel 
	{
		var $name = 'Resumesteps';
		var $useTable = 'resumesteps';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
<?php
	class jobberlandJobType extends AppModel 
	{
		var $name = 'jobberlandJobType';
		var $useTable = 'jobberland_job2type';
	}
?>

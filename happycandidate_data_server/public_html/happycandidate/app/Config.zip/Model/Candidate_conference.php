<?php
	class Candidate_conference extends AppModel 
	{
		var $name = 'Candidate_conference';
		var $useTable = 'candidate_conference';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
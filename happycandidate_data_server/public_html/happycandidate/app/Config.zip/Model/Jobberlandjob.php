    <?php
		class Jobberlandjob extends AppModel 
		{
			var $name = 'Jobberlandjob';
			var $useTable = 'jobberland_job';
		}
    ?>

<?php
	class Candidate_research extends AppModel 
	{
		var $name = 'Candidate_research';
		var $useTable = 'candidate_research';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
<?php
	class Candidate_invited extends AppModel 
	{
		var $name = 'Candidate_invited';
		var $useTable = 'candidate_invited';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
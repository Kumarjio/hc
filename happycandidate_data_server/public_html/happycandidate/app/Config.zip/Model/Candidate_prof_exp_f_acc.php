<?php
	class Candidate_prof_exp_f_acc extends AppModel 
	{
		var $name = 'Candidate_prof_exp_f_acc';
		var $useTable = 'cand_prof_exp_f_acc';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
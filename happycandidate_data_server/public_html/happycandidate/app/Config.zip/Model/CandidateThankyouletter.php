<?php
	class CandidateThankyouletter extends AppModel 
	{
		var $name = 'CandidateThankyouletter';
		var $useTable = 'candidate_thankyou_letter';
	}
?>

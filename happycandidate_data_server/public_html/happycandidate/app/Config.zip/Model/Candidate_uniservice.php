<?php
	class Candidate_uniservice extends AppModel 
	{
		var $name = 'Candidate_uniservice';
		var $useTable = 'candidate_uniservice';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
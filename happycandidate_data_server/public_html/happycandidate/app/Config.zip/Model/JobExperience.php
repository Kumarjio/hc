<?php
	class JobExperience extends AppModel 
	{
		var $name = 'JobExperience';
		var $useTable = 'jobberland_experience';		
		
	}
?>
    <?php
		class Jobberlandcountry extends AppModel 
		{
			var $name = 'Jobberlandcountry';
			var $useTable = 'jobberland_countries';
		}
    ?>

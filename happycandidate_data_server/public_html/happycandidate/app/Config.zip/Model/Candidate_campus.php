<?php
	class Candidate_campus extends AppModel 
	{
		var $name = 'Candidate_campus';
		var $useTable = 'candidate_campus';
		
							 
		public function beforeSave($options = array())
		{
		}
		
	}
?>
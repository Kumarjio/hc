<?php
App::uses('Component', 'Controller');
class SkillSoftComponent extends Component 
{
    public $components = array('Session');
	 
	public function startup(Controller $controller) {
		$this->Controller = $controller;
	}
	
	public function fnskillsoftRegistration($arrUserInfo = array())
	{
		App::import('Vendor', 'skillsoft/olsalib');
		
		$userName = $arrUserInfo['userName'];
		$firstName = $arrUserInfo['firstName'];
		$lastName = $arrUserInfo['lastName'];
		$actionType = $arrUserInfo['actionType'];
		$assetId = $arrUserInfo['assetId'];
		$catalogPath = $arrUserInfo['catalogPath'];
		$response1 = SO_GetMultiActionSignOnUrl($userName, $actionType, $assetId, $firstName, $lastName); //First and Last Names are optional after initial setup.

		if($response1->success)
		{
			$olsasoapresponse = UD_GetAssetResults($userName,$assetId,true);
			$response2 = AS_SetCatalogAssignmentByUser($catalogPath, $userName);
			//echo "<a target='_blank' href='" . $response1->result->olsaURL . "' > Launch </a>";
			return  $response1->result->olsaURL;
			
		}
		else
		{
			return 0;
		}
	}
	public function GetuserLogin($userName)
	{
		App::import('Vendor', 'skillsoft/olsalib');
		$assetId="";
		$response1 = SO_GetMultiActionSignOnUrl($userName);
		$olsasoapresponse = UD_GetAssetResults($userName,$assetId,true);
		
		return  $response1->result->olsaURL;
	}	
	
	

}
?>